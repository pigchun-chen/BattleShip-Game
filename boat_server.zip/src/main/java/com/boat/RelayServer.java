package com.boat;// RelayServer.java

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import java.util.Scanner;
import java.util.concurrent.ConcurrentLinkedQueue;

public class RelayServer {

    private static final Map<String, PrintWriter> clients = new HashMap<>();
    private static final Map<String, Queue<String>> messageQueue = new HashMap<>();

    public static void main(String[] args) {
        final int PORT = 8888;

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server started. Waiting for clients...");

            while (true) {
                // Waiting for the client to connect
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected: " + clientSocket);

                // Create a new thread to handle client connections
                Thread clientThread = new Thread(new ClientHandler(clientSocket));
                clientThread.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class ClientHandler implements Runnable {
        private Socket clientSocket;
        private String clientId;

        public ClientHandler(Socket socket) {
            this.clientSocket = socket;
        }

        @Override
        public void run() {
            try {
                // Get the input and output streams
                Scanner in = new Scanner(clientSocket.getInputStream());
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);

                // 读取客户端的身份信息
                clientId = in.nextLine();
                System.out.println("Client ID: " + clientId + " connected.");

                // Read the client's identity
                clients.put(clientId, out);

                // Check if there is a message in the queue waiting to be sent to the client.
                if (messageQueue.containsKey(clientId)) {
                    Queue<String> queue = messageQueue.get(clientId);
                    while (!queue.isEmpty()) {
                        out.println(queue.poll());
                    }
                }

                // Processing client messages
                while (true) {
                    String message = in.nextLine();
                    System.out.println("Received from client " + clientId + ": " + message);

                    // Check if the message is a request sent to another client
                    if (message.startsWith("/sendto")) {
                        String[] parts = message.split(" ");
                        if (parts.length >= 3) {
                            String recipient = parts[1];
                            String content = message.substring(message.indexOf(parts[2]));
                            sendMessageToClient(recipient, content);
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                // Remove the output stream from the client mapping
                clients.remove(clientId);
                System.out.println("Client ID: " + clientId + " disconnected.");
                try {
                    clientSocket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        private void sendMessageToClient(String recipient, String message) {
            PrintWriter recipientOut = clients.get(recipient);
            if (recipientOut != null) {
                recipientOut.println(message);
            } else {
                // If the target client is not connected, put the message in a queue and wait for it to be sent.
                Queue<String> queue = messageQueue.getOrDefault(recipient, new ConcurrentLinkedQueue<>());
                queue.offer(message);
                messageQueue.put(recipient, queue);
            }
        }
    }
}
