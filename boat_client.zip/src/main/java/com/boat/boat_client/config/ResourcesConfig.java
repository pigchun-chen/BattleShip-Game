package com.boat.boat_client.config;

public final class ResourcesConfig {
    public final static int STAGE_WIDTH = 720;
    public final static int STAGE_HEIGHT = 1080;


    // Load resource image
    public final static String BOX_BLUE = "D:\\342-java\\boat_client\\src\\main\\resources\\static\\box_blue.png";
    public final static String BOX_GREEN = "D:\\342-java\\boat_client\\src\\main\\resources\\static\\box_g.png";
    public final static String BOX_RED = "D:\\342-java\\boat_client\\src\\main\\resources\\static\\box_red.png";
    public final static String[] BOAT = {
            "",
            "",
            "D:\\342-java\\boat_client\\src\\main\\resources\\static\\boats\\boat_2.png",
            "D:\\342-java\\boat_client\\src\\main\\resources\\static\\boats\\boat_3.png",
            "D:\\342-java\\boat_client\\src\\main\\resources\\static\\boats\\boat_4.png",
            "D:\\342-java\\boat_client\\src\\main\\resources\\static\\boats\\boat_5.png"
    };
}
