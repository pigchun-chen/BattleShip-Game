package com.boat.boat_client.Entity;

public class GameMap {
    private int[][] map;

    // Five types of ships on the current map
    private Boat[] boats;

    public GameMap() {
        // Initialize map size
        map = new int[6][10];
        boats = new Boat[5];

        initBoat();
    }

    private void initBoat() {
        //Initialize the ship's position
        boats[0] = new Boat(1, new int[]{0, 0}, 5); // 长度 5
        boats[1] = new Boat(2, new int[]{0, 1}, 4); // 长度 4
        boats[2] = new Boat(3, new int[]{0, 2}, 3); // 长度 3
        boats[3] = new Boat(4, new int[]{0, 3}, 3); // 长度 3
        boats[4] = new Boat(5, new int[]{0, 4}, 2); // 长度 2

        for (Boat boat : boats) {
            setBoatPos(boat);
        }
    }

    public void setBoatPos(Boat boat) {
        // Set the ship's position to the corresponding id.
        for (int i = 0; i < boat.getLen(); i++) {
            if (boat.getDirection() == 0) {
                map[boat.getBegin_pos()[0] + i][boat.getBegin_pos()[1]] = boat.getId();
            } else {
                map[boat.getBegin_pos()[0]][boat.getBegin_pos()[1] + i] = boat.getId();
            }
        }
    }


    public void reSetBoatPos(Boat boat) {
        // Corresponding information is processed after rotation
        int old_direction = boat.getDirection() == 0 ? 1 : 0;
        // Set the original position to 0
        for (int i = 0; i < boat.getLen(); i++) {
            if (old_direction == 0) {
                map[boat.getBegin_pos()[0] + i][boat.getBegin_pos()[1]] = 0;
            } else {
                map[boat.getBegin_pos()[0]][boat.getBegin_pos()[1] + i] = 0;
            }
        }
        // Update Location
        setBoatPos(boat);
    }

    public void reMoveBoatPos(Boat boat) {
        // Set the ship's position to zero.
        for (int i = 0; i < boat.getLen(); i++) {
            if (boat.getDirection() == 0) {
                map[boat.getBegin_pos()[0] + i][boat.getBegin_pos()[1]] = 0;
            } else {
                map[boat.getBegin_pos()[0]][boat.getBegin_pos()[1] + i] = 0;
            }
        }
    }

    public int[][] getMap() {
        return map;
    }

    public Boat[] getBoats() {
        return boats;
    }


    // Convert to string and send
    public String boatsToString() {
        // id - begin_pos - direction - len
        StringBuilder sb = new StringBuilder();
        for (Boat boat : boats) {
            sb.append(
                    boat.getId()).append("-"). // ID
                    append(boat.getBegin_pos()[0]).append(boat.getBegin_pos()[1]).append("-"). // pos
                    append(boat.getLen()).append("-"). // len
                    append(boat.getDirection()).append(","); // dir
        }
        return sb.toString();
    }
}
