package com.boat.boat_client.Entity;

public class Boat {

    // five ships
    private int id;

    // lengths
    private int len;

    // Current ship's position Record start and direction
    private int[] begin_pos;

    // 0 (down), 1 (right)
    private int direction;

    // Initialize the ship's position. Initial position is all the way down.
    public Boat(int id, int[] begin_pos, int len) {
        this.id = id;
        this.begin_pos = begin_pos;
        this.direction = 0;
        this.len = len;
    }
    public Boat(int id, int[] begin_pos, int len, int direction) {
        this.id = id;
        this.begin_pos = begin_pos;
        this.direction = direction;
        this.len = len;
    }

    public int getLen() {
        return len;
    }

    public void setLen(int len) {
        this.len = len;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int[] getBegin_pos() {
        return begin_pos;
    }

    public void setBegin_pos(int[] begin_pos) {
        this.begin_pos = begin_pos;
    }

    public int getDirection() {
        return direction;
    }

    public void setDirection(int direction) {
        this.direction = direction;
    }

    // string to object (computing)
    public static Boat strToBoat(String str) {
        String[] strs = str.split("-");
        int id = Integer.parseInt(strs[0]);
        int[] begin_pos = new int[2];
        begin_pos[0] = Integer.parseInt(String.valueOf(strs[1].charAt(0)));
        begin_pos[1] = Integer.parseInt(String.valueOf(strs[1].charAt(1)));
        int len = Integer.parseInt(strs[2]);
        int direction = Integer.parseInt(strs[3]);
        return new Boat(id, begin_pos, len, direction);
    }

    public static Boat[] strToBoats(String str) {
        String[] strs = str.split(",");
        Boat[] boats = new Boat[strs.length];
        for (int i = 0; i < strs.length; i++) {
            boats[i] = strToBoat(strs[i]);
        }
        return boats;
    }
}
