package com.boat.boat_client.game;

import com.boat.boat_client.Entity.Boat;
import com.boat.boat_client.Entity.GameMap;
import javafx.event.EventHandler;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;

public class BoatUtil {
    // 处理Boat元素对应的 点击事件信息
    public static void addClickEvent(ImageView view, Boat boat, GameMap map, GridPane gridPane) {
        view.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                if (mouseEvent.getButton().name().equals("SECONDARY")) {
                    BoatUtil.rotate(view, boat, map, gridPane);
                    System.out.println("click rotate: " + boat.getDirection());
                }

            }
        });
    }

    public static boolean checkBoatPos(Boat boat, GameMap my) {
        int direction = boat.getDirection();
        int new_d = direction == 0 ? 1 : 0;
        int[][] map = my.getMap();

        int id = boat.getId();

        for (int i = 1; i < boat.getLen(); i++) {
            if (new_d == 0) {
                if (boat.getBegin_pos()[0] + i >= 6) {
                    return false;
                }
                int pos_id = map[boat.getBegin_pos()[0] + i][boat.getBegin_pos()[1]];
                if (pos_id != 0 && pos_id != id) {
                    // 当不是空地
                    return false;
                }
            } else {
                if (boat.getBegin_pos()[1] + i >= 10) {
                    return false;
                }
                int pos_id = map[boat.getBegin_pos()[0]][boat.getBegin_pos()[1] + i];

                if (pos_id != 0 && pos_id != id) {
                    // 当不是空地
                    return false;
                }
            }
        }

        return true;
    }

    // 处理旋转 根据当前的方向
    public static void rotate(ImageView view, Boat boat, GameMap map, GridPane gridPane) {
        int direction = boat.getDirection();
        int new_d = direction == 0 ? 1 : 0;

        // 处理布局问题 查看是否可以旋转
        // 当可以不可以旋转的时候退出
        if (!BoatUtil.checkBoatPos(boat, map)) {
            System.out.printf("can not rotate");
            return;
        }

        boat.setDirection(new_d);
        int len = boat.getLen();
        // 逆时针
        if (direction == 0) {
            // 原始的位置的 处理
            GridPane.setRowSpan(view, 1);
            GridPane.setColumnSpan(view, boat.getLen());
            view.setTranslateX((len - 1) * 30);
            view.setRotate(-90);
        } else {
            GridPane.setRowSpan(view, boat.getLen());
            GridPane.setColumnSpan(view, 1);
            view.setTranslateX(0);
            view.setRotate(0);
        }
        // 重新处理位置信息
        map.reSetBoatPos(boat);
        System.out.println("flush");
    }


    // 添加拖拽事件
    public static void addDragEvent(ImageView view, Boat boat, GameMap map, GridPane gridPane) {
        view.setOnMouseDragged(new EventHandler<MouseEvent>() {
            // 处理拖拽事件 方向
            private double lastX;
            private double lastY;
            //            private Timer timer;
            public boolean canDrag = true;

            private int lastDirection = 0;

            //                    // 处理变化的长度 为 30左右即可 改变位置后初始化为 0
//                    private double temp_len_x;
//                    private double temp_len_y;
            @Override
            public void handle(MouseEvent mouseEvent) {
//                // 取消之前的定时器任务
//                if (timer != null) {
//                    timer.cancel();
//                }
                if (!mouseEvent.getButton().name().equals("PRIMARY")) {
                    return;
                }

                if (!canDrag) {
                    return;
                }

                // 获取当前鼠标位置
                double currentX = mouseEvent.getX();
                double currentY = mouseEvent.getY();

                // 检查当前的鼠标位置是否超出Grid的位置

                // 计算鼠标位置的变化
                double deltaX = currentX - lastX;
                double deltaY = currentY - lastY;

                // 处理最开始的变化
//                        temp_len_x += deltaX;
//                        temp_len_y += deltaY;
//
//                        if (!((temp_len_x > 30 || temp_len_y > 30) && (lastX > 0 && lastY > 0))) {
//                            System.out.println("not move enough");
//                            lastX = currentX;
//                            lastY = currentY;
//                            return;
//                        }

//                timer = new Timer();
//                timer.schedule(new TimerTask() {
//                    @Override
//                    public void run() {
//                        int move_direction = BoatUtil.getMoveDirection(deltaX, deltaY, boat.getDirection());
//                        // 处理拖拽后的位置更新
//                        BoatUtil.updateBoatPos(view, boat, map, gridPane, move_direction);
//
//                    }
//                }, 50);

                int move_direction = BoatUtil.getMoveDirection(deltaX, deltaY, boat.getDirection());

                if (move_direction == lastDirection) {
                    // 处理拖拽事件
                    BoatUtil.updateBoatPos(view, boat, map, gridPane, move_direction);
                    System.out.println("更新");
                    canDrag = false;
                    new Thread(() -> {
                        try {
                            Thread.sleep(520);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        } finally {
                            canDrag = true;
                        }
                    }).start();
                }

                // 更新上一次的鼠标位置
                lastX = currentX;
                lastY = currentY;
                lastDirection = move_direction;
            }
        });
    }

    // 处理方向 上、下、左、 右
    // r、l、d、u: 1, 2, 3, 4
    public static int getMoveDirection(double deltaX, double deltaY, int boat_direction) {
        // 比较变化来确定拖拽方向
        if (boat_direction == 0) {
            if (Math.abs(deltaX) > Math.abs(deltaY)) {
                if (deltaX > 0) {
                    System.out.println("right");
                    return 1;
                } else {
                    System.out.println("left");
                    return 2;
                }
            } else {
                if (deltaY > 0) {
                    System.out.println("down");
                    return 3;
                } else {
                    System.out.println("up");
                    return 4;
                }
            }
        } else {
            // boat_direction 会影响 所有的反过来
            if (Math.abs(deltaX) > Math.abs(deltaY)) {
                if (deltaX > 0) {
                    System.out.println("down");
                    return 4;
                } else {
                    System.out.println("up");
                    return 3;
                }
            } else {
                if (deltaY > 0) {
                    System.out.println("right");
                    return 1;
                } else {
                    System.out.println("left");
                    return 2;
                }
            }
        }


    }


    // 处理位置的更新
    public static void updateBoatPos(ImageView view, Boat boat, GameMap map, GridPane gridPane, int move_direction) {
        // 获取当前在gridPane位置 根据move_direction更新位置
        int row = GridPane.getRowIndex(view);
        int col = GridPane.getColumnIndex(view);

        int boat_direction = boat.getDirection();
        switch (move_direction) {
            case 1: // right
                // 检查是否越界 横向的检查
                if (boat_direction == 1 && (col + boat.getLen() >= 10)) {
                    // 越界退出
                    return;
                }
                // 检查是否越界 纵向的检查
                if (boat_direction == 0 && (col + 1 >= 10)) {
                    // 越界退出
                    return;
                }

                // 更新位置
                col += 1;
                break;

            case 2: // left
                if (col - 1 < 0) {
                    // 越界退出
                    return;
                }
                col -= 1;
                break;

            case 3: // down
                if (boat_direction == 0 && (row + boat.getLen() >= 6)) {
                    return;
                }
                row += 1;
                break;

            case 4: // up
                if (row - 1 < 0) return;
                row -= 1;
                break;

            default:
                System.out.println("error");
                break;
        }

        // 更新位置 检查移动后的 位置是否有船
        int[][] game_map = map.getMap();
        if ((col < 10 && row < 6) && (game_map[row][col] == 0 || game_map[row][col] == boat.getId())) {
            // 移动位置没有船 更新位置
            GridPane.setRowIndex(view, row);
            GridPane.setColumnIndex(view, col);
            // 更新地图
            map.reMoveBoatPos(boat);

            // 更新元素自己的位置
            boat.setBegin_pos(new int[]{row, col});
            // 更新地图
            map.setBoatPos(boat);
        }
    }
}
