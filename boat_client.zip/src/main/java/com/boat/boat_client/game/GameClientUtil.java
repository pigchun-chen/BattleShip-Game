package com.boat.boat_client.game;

import java.io.*;
import java.net.*;
import java.util.Deque;
import java.util.Scanner;
import java.util.concurrent.*;

public class GameClientUtil {

//    public String id = "";
//
//    public BufferedWriter writer;
//    public BufferedReader reader;
//    public Socket socket;
//
//    public GameClientUtil() {
//        // 启动连接服务
//        try {
//            socket = new Socket("127.0.0.1", 8888);
//            writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
//            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//
//    // 获取消息
//    public String getMessage() {
//        String message = null;
//        try {
//            message = reader.readLine();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return message;
//    }
//
//    // 发送消息
//    public void sendMessage(String message) {
//        System.out.println("send msg: " + message);
//        try {
//            writer.write(message);
//            writer.newLine();
//            writer.flush();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }

    // 初始化信息
//    public void init() {
//        this.id = this.getMessage();
//   }

//    public static void main(String[] args) {
//        GameClientUtil gameClientUtil = new GameClientUtil();
//        gameClientUtil.id = gameClientUtil.getMessage();
//        while (true) {
//            gameClientUtil.sendMessage(gameClientUtil.id);
//        }
//    }

    public static Deque<String> messageQueue = new LinkedBlockingDeque<>();

    public static Scanner in = null;
    public static PrintWriter out = null;

    public static int id = 0;
    public static void init() {
        final String SERVER_IP = "127.0.0.1"; // 服务器 IP 地址
        final int SERVER_PORT = 8888; // 服务器端口

        try {
            // 连接到服务器
            Socket socket = new Socket(SERVER_IP, SERVER_PORT);
            System.out.println("Connected to server.");

            // 获取输入输出流
            in = new Scanner(socket.getInputStream());
            out = new PrintWriter(socket.getOutputStream(), true);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void run() {
        init();
        // 向服务器发送客户端ID
        out.println(id);

        // 创建一个新线程用于接收服务器发送的消息
        Thread receiveThread = new Thread(() -> {
            while (true) {
                if (in.hasNextLine()) {
                    String message = in.nextLine();
                    System.out.println("Received message: " + message);
                    // 存入队列中
                    GameClientUtil.messageQueue.add(message);
                }
            }
        });
        receiveThread.start();
    }

    public static void sendMessage(String message) {
        out.println("/sendto "+ (id == 0 ? 1 : 0) + " " + message);
    }

    // 从队列中取出消息
    public static String getMessage() {
        return messageQueue.poll();
    }
}
