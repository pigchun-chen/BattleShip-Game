package com.boat.boat_client.game;

import com.boat.boat_client.Entity.GameMap;

public class GameUtil {
    // 处理对方的状态 - 1. AI

    // 获取初始化地图
    public static GameMap getInitMap() {
        GameMap map = new GameMap();
        // 额外处理
        map.getBoats()[4].setDirection(1);
        map.reSetBoatPos(map.getBoats()[4]);
        return map;
    }

    // 模拟操作 一维数组的方式
    int[][] book = new int[6][10];

    public GameUtil() {
    }

    public int[] simulate() {
        int x = 0;
        int y = 0;
        // 随机生产对应位置
        while (true) {
            x = (int) (Math.random() * 6);
            y = (int) (Math.random() * 10);
            if (book[x][y] == 0) {
                book[x][y] = 1;
                return new int[]{x, y};
            }
        }
    }
}
