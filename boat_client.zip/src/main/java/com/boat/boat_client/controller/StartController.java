package com.boat.boat_client.controller;

import com.boat.boat_client.BoatApplication;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;

import java.util.Objects;

public class StartController {

    @FXML
    private ImageView startButton;

    @FXML
    private VBox startView;

    public void startGame(MouseEvent mouseEvent) {
        Scene scene = startView.getScene();
        // Load a new interface
        try {
            Parent root = FXMLLoader.load(Objects.requireNonNull(BoatApplication.class.getResource("game-view.fxml")));
            scene.setRoot(root);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
