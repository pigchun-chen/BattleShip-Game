package com.boat.boat_client.controller;

import com.boat.boat_client.BoatApplication;
import com.boat.boat_client.Entity.Boat;
import com.boat.boat_client.Entity.GameMap;
import com.boat.boat_client.config.ResourcesConfig;
import com.boat.boat_client.game.BoatUtil;
import com.boat.boat_client.game.GameClientUtil;
import com.boat.boat_client.game.GameUtil;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextInputDialog;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;

import java.net.URL;
import java.util.Objects;
import java.util.Optional;
import java.util.ResourceBundle;

import static java.lang.Thread.sleep;

public class GameController implements Initializable {

    @FXML
    public AnchorPane gameView;

    @FXML
    public ImageView startButton;
    public ImageView shuffleButton;
    public ImageView yourTurn;

    @FXML
    private ImageView home_button;

    @FXML
    private GridPane my_map;

    @FXML
    private GridPane enemy_map;

    private Thread gameThread;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        loadMap();
        yourTurn.setVisible(false);
    }

    @FXML
    public void homeButtonClick() {
        Scene scene = gameView.getScene();
        if (gameThread != null) {
            /// End the thread
            gameThread.stop();
        }
        //Load new interface
        try {
            Parent root = FXMLLoader.load(Objects.requireNonNull(BoatApplication.class.getResource("index-view.fxml")));
            scene.setRoot(root);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Load the board
    private GameMap myGameMap;

    private GameMap enemyGameMap;

    public void loadMap() {
        // Create two boards, one for the opponent and one for your side.
        GameMap enemy = new GameMap();
        GameMap my = new GameMap();

        int[][] map = enemy.getMap();
        enemyGameMap = enemy;
        setCells(map, enemy_map, enemy_cells, 1);

        map = my.getMap();
        setCells(map, my_map, my_cells, 0);

        // Load the positions of the elements on your own board.
        myGameMap = my;
        setBoats(my_map, my);
    }

    // Set the current position of your ship on the board.
    public void setBoats(GridPane myMap, GameMap my) {
        Boat[] boats = my.getBoats();

        for (Boat boat : boats) {
            // Be aware of cross-column and cross-row
            ImageView boat_cell = new ImageView();
            boat_cell.setImage(new javafx.scene.image.Image(ResourcesConfig.BOAT[boat.getLen()]));

            // Add event 1. drag and drop 2. click to rotate
            BoatUtil.addClickEvent(boat_cell, boat, my, myMap);
            BoatUtil.addDragEvent(boat_cell, boat, my, myMap);

            // Handle rows and columns
            if (boat.getDirection() == 0) {
                //  perpendicular
                int[] pos = boat.getBegin_pos();
                GridPane.setRowSpan(boat_cell, boat.getLen());
                myMap.add(boat_cell, pos[1], pos[0]);
            } else {
                // sideways
            }
        }
    }

    //  Processes the position information of the corresponding element
    private ImageView[][] my_cells = new ImageView[6][10];
    private ImageView[][] enemy_cells = new ImageView[6][10];

    private Integer[] enemyClickInfo = {-1, -1};

    // flag Marking the Enemy
    private void setCells(int[][] map, GridPane myMap, ImageView[][] cells, int flag) {
        for (int i = 0; i < map.length; i++) {
            for (int i1 = 0; i1 < map[i].length; i1++) {
                ImageView cell = new ImageView();
                cell.setImage(new javafx.scene.image.Image(ResourcesConfig.BOX_BLUE));
                myMap.add(cell, i1, i);
                cells[i][i1] = cell;

                if (flag == 1) {
                    cell.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> {
                        // Handling the current click event
                        Integer columnIndex = GridPane.getColumnIndex(cell);
                        Integer rowIndex = GridPane.getRowIndex(cell);
                        enemyClickInfo[0] = rowIndex;
                        enemyClickInfo[1] = columnIndex;
                        System.out.println("now cell was clicked" + columnIndex + "-" + rowIndex);

                    });
                }
            }
        }
    }

    // Start the game
    public void startGame(MouseEvent mouseEvent) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Game Mode");
        alert.setHeaderText("Please select the corresponding game mode");
        alert.setContentText("Choose your options：");

        ButtonType buttonTypeOne = new ButtonType("human-computer");
        ButtonType buttonTypeTwo = new ButtonType("two people battle");
        ButtonType buttonTypeCancel = new ButtonType("cancel", ButtonBar.ButtonData.CANCEL_CLOSE);

        alert.getButtonTypes().setAll(buttonTypeOne, buttonTypeTwo, buttonTypeCancel);

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == buttonTypeOne) {
            // Process human-machine mode content Machine first
            startButton.setVisible(false);
            shuffleButton.setVisible(false);
            // Initialize the enemy's corresponding map - don't draw it yet, just record the location.
//            initEnemyMap(GameUtil.getInitMap());
            GameMap enemyMap = GameUtil.getInitMap();
            handleEnemyPos(enemyMap);
            GameUtil gameUtil = new GameUtil();

            // Round Signs Odd numbers are for our troops Even numbers are for enemy troops
            gameThread = new Thread(() -> {
                int flag = 0;
                while (true) {
                    int[] pos = new int[2];
                    // Ensure response events are loaded successfully
                    try {
                        sleep(500);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                    if (enemyClickInfo[0] != -1 && enemyClickInfo[1] != -1) {
                        // Get the click position
                        pos[0] = enemyClickInfo[0];
                        pos[1] = enemyClickInfo[1];
                        enemyClickInfo[0] = -1;

                        yourTurn.setVisible(false);

                        // flashes the corresponding position
                        ImageView imageView = enemy_cells[pos[0]][pos[1]];

                        for (int i = 0; i < 3; i++) {
                            imageView.setImage(new javafx.scene.image.Image(ResourcesConfig.BOX_GREEN));
                            try {
                                sleep(250);
                            } catch (InterruptedException e) {
                                throw new RuntimeException(e);
                            }
                            imageView.setImage(new javafx.scene.image.Image(ResourcesConfig.BOX_RED));
                            try {
                                sleep(250);
                            } catch (InterruptedException e) {
                                throw new RuntimeException(e);
                            }
                        }
                        // Confirm final value
                        if (enemyMap.getMap()[pos[0]][pos[1]] > 0) {
                            // is red
                            imageView.setImage(new javafx.scene.image.Image(ResourcesConfig.BOX_RED));
                        } else {
                            // is green
                            imageView.setImage(new javafx.scene.image.Image(ResourcesConfig.BOX_GREEN));
                        }
                        // Updated map values
                        setEnemyMap(enemyMap, enemyMap.getMap()[pos[0]][pos[1]], pos[0], pos[1]);

                        flag = 0; // opponent's turn
                        if (checkWin(enemyMap)) {
                            Platform.runLater(() -> {
                                Alert winAlert = new Alert(Alert.AlertType.CONFIRMATION);
                                winAlert.setTitle("Confirmation Dialog");
                                winAlert.setHeaderText("You win!");
                                winAlert.setContentText("Confirmation of exit!");
                                Optional<ButtonType> res = winAlert.showAndWait();
                                if (res.get() == ButtonType.OK) {
                                } else {
                                }
                                System.exit(0);
                            });

//                            System.exit(0);
                        }
                    } else {
                        if (flag == 1) {
                            continue;
                        }
                        // Getting the other side of the action
                        pos = gameUtil.simulate();

                        // Flashes the corresponding position
                        ImageView imageView = my_cells[pos[0]][pos[1]];

                        for (int i = 0; i < 3; i++) {
                            imageView.setImage(new javafx.scene.image.Image(ResourcesConfig.BOX_GREEN));
                            try {
                                sleep(250);
                            } catch (InterruptedException e) {
                                throw new RuntimeException(e);
                            }
                            imageView.setImage(new javafx.scene.image.Image(ResourcesConfig.BOX_RED));
                            try {
                                sleep(250);
                            } catch (InterruptedException e) {
                                throw new RuntimeException(e);
                            }
                        }
                        // Confirmation of final value
                        if (myGameMap.getMap()[pos[0]][pos[1]] > 0) {
                            // is red
                            imageView.setImage(new javafx.scene.image.Image(ResourcesConfig.BOX_RED));
                        } else {
                            // is green
                            imageView.setImage(new javafx.scene.image.Image(ResourcesConfig.BOX_GREEN));
                        }
                        // Updated map values
                        myGameMap.getMap()[pos[0]][pos[1]] = -1;
                        // request a click
                        yourTurn.setVisible(true);
                        flag = 1;

                        if (checkWin(myGameMap)) {
                            yourTurn.setVisible(false);
                            Platform.runLater(() -> {
                                Alert winAlert = new Alert(Alert.AlertType.CONFIRMATION);
                                winAlert.setTitle("Confirmation Dialog");
                                winAlert.setHeaderText("You failed!");
                                winAlert.setContentText("Confirmation of exit!");
                                Optional<ButtonType> res = winAlert.showAndWait();
                                if (res.get() == ButtonType.OK) {
                                } else {
                                }
                                System.exit(0);
                            });
                        }
                    }

                }
            });
            gameThread.start();
        } else if (result.get() == buttonTypeTwo) {
            startButton.setVisible(false);
            shuffleButton.setVisible(false);

            // Handling of long-distance matchmaking
            gameThread = new Thread(() -> {


                // Get ID
                Platform.runLater(() -> {
                    TextInputDialog dialog = new TextInputDialog("0");
                    dialog.setTitle("Enter the corresponding ID");
                    dialog.setHeaderText("Enter the corresponding ID 0, 1");
                    dialog.setContentText("Please enter the corresponding Id");

                    Optional<String> res = dialog.showAndWait();
                    res.ifPresent(s -> {
                        // Initialize the corresponding parameter
                        GameClientUtil.id = Integer.parseInt(s);
                        GameClientUtil.run();
                        GameClientUtil.sendMessage("boats-" + myGameMap.boatsToString());
                    });
                });

                while (true) {
                    try {
                        sleep(500);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                    String message = GameClientUtil.getMessage();
                    if (message == null) continue;

                    int[] pos = new int[2];
                    if (message.startsWith("boats-")) {
                        message = message.substring(6);
                        Boat[] boats = Boat.strToBoats(message);
                        Boat[] boats1 = enemyGameMap.getBoats();
                        System.arraycopy(boats, 0, boats1, 0, boats.length);

                        // Handle initialization positions
                        handleEnemyPos(enemyGameMap);
                        // If it's a one, let the other side begin
                        if (GameClientUtil.id == 1) {
                            GameClientUtil.sendMessage("yt");
                        }
                    } else if (message.startsWith("yt")) {
                        // My turn
                        Platform.runLater(() -> {
                            yourTurn.setVisible(true);
                        });


                        while (true) {
                            try {
                                sleep(500);
                            } catch (InterruptedException e) {
                                throw new RuntimeException(e);
                            }
                            if (enemyClickInfo[0] != -1 && enemyClickInfo[1] != -1) {
                                // Get click position
                                pos[0] = enemyClickInfo[0];
                                pos[1] = enemyClickInfo[1];
                                // Send a click message
                                enemyClickInfo[0] = -1;

                                yourTurn.setVisible(false);

                                // Flashes the corresponding position
                                ImageView imageView = enemy_cells[pos[0]][pos[1]];

                                for (int i = 0; i < 3; i++) {
                                    imageView.setImage(new javafx.scene.image.Image(ResourcesConfig.BOX_GREEN));
                                    try {
                                        sleep(250);
                                    } catch (InterruptedException e) {
                                        throw new RuntimeException(e);
                                    }
                                    imageView.setImage(new javafx.scene.image.Image(ResourcesConfig.BOX_RED));
                                    try {
                                        sleep(250);
                                    } catch (InterruptedException e) {
                                        throw new RuntimeException(e);
                                    }
                                }
                                // Confirmation of final value
                                if (enemyGameMap.getMap()[pos[0]][pos[1]] > 0) {
                                    // is red
                                    imageView.setImage(new javafx.scene.image.Image(ResourcesConfig.BOX_RED));
                                } else {
                                    // is green
                                    imageView.setImage(new javafx.scene.image.Image(ResourcesConfig.BOX_GREEN));
                                }
                                // Updated map values
                                setEnemyMap(enemyGameMap, enemyGameMap.getMap()[pos[0]][pos[1]], pos[0], pos[1]);

                                if (checkWin(enemyGameMap)) {
                                    Platform.runLater(() -> {
                                        Alert winAlert = new Alert(Alert.AlertType.CONFIRMATION);
                                        winAlert.setTitle("Confirmation Dialog");
                                        winAlert.setHeaderText("You win!");
                                        winAlert.setContentText("Confirmation of exit!");
                                        Optional<ButtonType> res = winAlert.showAndWait();
                                        if (res.get() == ButtonType.OK) {
                                        } else {
                                        }
                                        System.exit(0);
                                    });
                                }
                                GameClientUtil.sendMessage("yt");
                                GameClientUtil.sendMessage("click-" + (5 - pos[0]) + "-" + (9 - pos[1]));
                                break;
                            }
                        }
                    } else if (message.startsWith("click-")) {
                        message = message.substring(6);
                        String[] pos_str = message.split("-");
                        pos[0] = Integer.parseInt(pos_str[0]);
                        pos[1] = Integer.parseInt(pos_str[1]);


                        ImageView imageView = my_cells[pos[0]][pos[1]];

                        for (int i = 0; i < 3; i++) {
                            imageView.setImage(new javafx.scene.image.Image(ResourcesConfig.BOX_GREEN));
                            try {
                                sleep(250);
                            } catch (InterruptedException e) {
                                throw new RuntimeException(e);
                            }
                            imageView.setImage(new javafx.scene.image.Image(ResourcesConfig.BOX_RED));
                            try {
                                sleep(250);
                            } catch (InterruptedException e) {
                                throw new RuntimeException(e);
                            }
                        }

                        if (myGameMap.getMap()[pos[0]][pos[1]] > 0) {

                            imageView.setImage(new javafx.scene.image.Image(ResourcesConfig.BOX_RED));
                        } else {

                            imageView.setImage(new javafx.scene.image.Image(ResourcesConfig.BOX_GREEN));
                        }

                        myGameMap.getMap()[pos[0]][pos[1]] = -1;

                        yourTurn.setVisible(true);

                        if (checkWin(myGameMap)) {
                            yourTurn.setVisible(false);
                            Platform.runLater(() -> {
                                Alert winAlert = new Alert(Alert.AlertType.CONFIRMATION);
                                winAlert.setTitle("Confirmation Dialog");
                                winAlert.setHeaderText("You failed!");
                                winAlert.setContentText("Confirmation of exit!");
                                Optional<ButtonType> res = winAlert.showAndWait();
                                if (res.get() == ButtonType.OK) {
                                } else {
                                }
                                System.exit(0);
                            });
                        }
                    }
                }

            });

            gameThread.start();
        }
    }


    public boolean checkWin(GameMap gameMap) {
        int[][] map = gameMap.getMap();

        for (int[] ints : map) {
            for (int anInt : ints) {
                if (anInt > 0) {
                    return false;
                }
            }
        }
        return true;
    }


    public void setEnemyMap(GameMap enemy, int id, int x, int y) {
        if (id == 0) return;
        //
        Boat[] boats = enemy.getBoats();
        Boat boat = boats[id - 1]; // 1 - 5



        int[][] map = enemy.getMap();
        map[x][y] = -1;

        if (boat.getDirection() == 0) {

            for (int i = 0; i < boat.getLen(); i++) {
                if (map[boat.getBegin_pos()[0] + i][boat.getBegin_pos()[1]] != -1) {
                    return;
                }
            }
        } else {

            for (int i = 0; i < boat.getLen(); i++) {
                if (map[boat.getBegin_pos()[0]][boat.getBegin_pos()[1] - i] != -1) {
                    return;
                }
            }
        }

//        for (Boat boat : boats) {
        ImageView boat_cell = new ImageView();
        boat_cell.setImage(new javafx.scene.image.Image(ResourcesConfig.BOAT[boat.getLen()]));


        int[] pos = boat.getBegin_pos();
        if (boat.getDirection() == 0) {

            GridPane.setRowSpan(boat_cell, boat.getLen());
            boat_cell.setRotate(180);

            Platform.runLater(() -> {
                enemy_map.add(boat_cell, pos[1], pos[0]);
            });
        } else {

            GridPane.setColumnSpan(boat_cell, boat.getLen());
            boat_cell.setRotate(90);
            boat_cell.setTranslateX(-(boat.getLen() - 1) * 30);

            Platform.runLater(() -> {
                enemy_map.add(boat_cell, pos[1], pos[0]);
            });
//            }
        }
    }


    public void handleEnemyPos(GameMap enemy) {
        Boat[] boats = enemy.getBoats();

        int[][] map = enemy.getMap();
        for (Boat boat : boats) {


            int[] pos = boat.getBegin_pos();
            enemy.reMoveBoatPos(boat);

            if (boat.getDirection() == 0) {

                boat.setBegin_pos(new int[]{5 - pos[0] - boat.getLen() + 1, 9 - pos[1]});
            } else {

                boat.setBegin_pos(new int[]{5 - pos[0], 9 - pos[1]});
            }
            for (int i = 0; i < boat.getLen(); i++) {
                if (boat.getDirection() == 0) {
                    map[boat.getBegin_pos()[0] + i][boat.getBegin_pos()[1]] = boat.getId();
                } else {
                    map[boat.getBegin_pos()[0]][boat.getBegin_pos()[1] - i] = boat.getId();
                }
            }
        }
        System.out.println("ok");
    }
}
