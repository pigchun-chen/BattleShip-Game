package com.boat.boat_client;

import com.boat.boat_client.config.ResourcesConfig;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class BoatApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        // Load Initial Scene
        FXMLLoader fxmlLoader = new FXMLLoader(BoatApplication.class.getResource("index-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), ResourcesConfig.STAGE_WIDTH, ResourcesConfig.STAGE_HEIGHT);
        stage.setTitle("Boat Game");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}